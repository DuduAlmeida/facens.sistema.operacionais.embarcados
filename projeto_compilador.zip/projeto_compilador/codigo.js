let a;
let b;
let c;

a = 5;
b = 3.5;
c = 3 * "12";

function teste(ab = 5, ba = c) {
  ab = ba;

  return 1;
}

let result;

result = teste(a, b);

class Jurema {
  constructor(f = 3, e = false) {}
}

if (a + 1) {
  a = 4;
  b = 4;
  c = 4;

  if (b + a == c) {
    c = b + 1;
  }
} else if (b) {
} else {
}

while (1) {
  a + 1;

  while (a) {
    console.log("as");
  }
}
